import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;

public class SlideShow extends JFrame {

	//Declare Variables
	private JPanel slidePane;
	private JPanel textPane;
	private JPanel buttonPane;
	private CardLayout card;
	private CardLayout cardText;
	private JButton btnPrev;
	private JButton btnNext;
	private JLabel lblSlide;
	private JLabel lblTextArea;

	/**
	 * Create the application.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {
		//Initialize variables to empty objects
		card = new CardLayout();
		cardText = new CardLayout();
		slidePane = new JPanel();
		textPane = new JPanel();
		textPane.setBackground(Color.BLUE);
		// expanded text box to fit third line of text
		textPane.setBounds(5, 470, 790, 60);
		textPane.setVisible(true);
		buttonPane = new JPanel();
		btnPrev = new JButton();
		btnNext = new JButton();
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		//Setup frame attributes
		
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("Top 5 Destinations SlideShow");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Setting the layouts for the panels
		slidePane.setLayout(card);
		textPane.setLayout(cardText);
		
		//logic to add each of the slides and text
		for (int i = 1; i <= 5; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();
			lblSlide.setText(getResizeIcon(i));
			lblTextArea.setText(getTextDescription(i));
			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		getContentPane().add(slidePane, BorderLayout.CENTER);
		getContentPane().add(textPane, BorderLayout.SOUTH);

		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);

		getContentPane().add(buttonPane, BorderLayout.SOUTH);
	}

	/**
	 * Previous Button Functionality
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}
	
	/**
	 * Next Button Functionality
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}

	/**
	 * Method to get the images
	 */
	private String getResizeIcon(int i) {
		String image = ""; 
		if (i==1){
			//replaced image with image for iceland retreat
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Iceland.jpg") + "'</body></html>";
		} else if (i==2){
			//replaced image with image or hawaii retreat
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Lanai_Hawaii.jpg") + "'</body></html>";
		} else if (i==3){
			//replaced image with image for spain retreat
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Mallorca,_Spain_02.jpg") + "'</body></html>";
		} else if (i==4){
			//replaced image with image for canada retreat
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Mont-Tremblant_Canada.jpg") + "'</body></html>";
		} else if (i==5){
			//replaced image with image for greece retreat
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Mykonos_Greece.jpg") + "'</body></html>";
		}
		return image;
	}
	
	/**
	 * Method to get the text values
	 */
	private String getTextDescription(int i) {
		String text = ""; 
		//replaced text in all cases to include new text for vacation options
		//added third line of code for the picture information
		if (i==1){
			text = "<html><body><font size='5'>#1 Renewal Retreat in Iceland.</font> <br>Beautiful outdoor hotsprings and meditation.</font> <br>Moyan Brenn, 2013, Gulfoss waterfall in September</body></html>";
		} else if (i==2){
			text = "<html><body><font size='5'>#2 Wellbeing retreat in Lana'i Hawai'i.</font> <br>Enjoy beautiful Lana'i with a tailored technology enhanced wellness retreat with spa and ocean access.</font> <br>Steve Jurvetson, 2008, Lava flows at Hulopoe Bay</body></html>";
		} else if (i==3){
			text = "<html><body><font size='5'>#3 Spiritual retreat in Mallorca Spain.</font> <br>Meditate on your spiritual self in the natural comfort of Mallorca.</font> <br>Dronepicr, 2019, Arial of beach Playa Cala Mesquida</body></html>";
		} else if (i==4){
			text = "<html><body><font size='5'>#4 Meditate and relax in Mont-Tremblant Canada.</font> <br>Set in the majastic canadian nature enjoy relaxing and cleasing yourself in meditation.</font> <br>Giggel, 2015, Mont-Tremblant - Quebec</body></html>";
		} else if (i==5){
			text = "<html><body><font size='5'>#5 Beachside yoga in Mykonos Greece.</font> <br>Set in breathtaking Mykonos enjoy the white sand beaches and amazing archetecture as you unwind.</font> <br>Dronepicr, 2020, The windmills in Mykonos</body></html>";
		}
		return text;
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}